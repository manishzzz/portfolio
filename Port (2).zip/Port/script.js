/* ══════════════════════════════════════
   Portfolio JS – Smooth, No Cursor
══════════════════════════════════════ */

// ─── Navbar ──────────────────────────────────────────────────────────────────
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 50);
    updateActiveNav();
}, { passive: true });

// Active nav link
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-link');
function updateActiveNav() {
    const scrollY = window.scrollY + 100;
    sections.forEach(s => {
        if (scrollY >= s.offsetTop && scrollY < s.offsetTop + s.offsetHeight) {
            navLinks.forEach(l => l.classList.remove('active'));
            const active = document.querySelector(`.nav-link[href="#${s.id}"]`);
            if (active) active.classList.add('active');
        }
    });
}
updateActiveNav();

// ─── Smooth-scroll links ──────────────────────────────────────────────────────
document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        const t = document.querySelector(link.getAttribute('href'));
        if (t) window.scrollTo({ top: t.offsetTop - 68, behavior: 'smooth' });
    });
});

// ─── Scroll Reveal ────────────────────────────────────────────────────────────
const revealEls = document.querySelectorAll('.reveal, .reveal-right');
const revealObs = new IntersectionObserver(entries => {
    entries.forEach(e => {
        if (e.isIntersecting) {
            e.target.classList.add('in-view');
            revealObs.unobserve(e.target);
        }
    });
}, { threshold: 0.1, rootMargin: '0px 0px -36px 0px' });
revealEls.forEach(el => revealObs.observe(el));

// ─── Counter ──────────────────────────────────────────────────────────────────
const counters = document.querySelectorAll('.stat-num[data-target]');
const countObs = new IntersectionObserver(entries => {
    entries.forEach(e => {
        if (e.isIntersecting && !e.target.dataset.done) {
            e.target.dataset.done = '1';
            const target = +e.target.dataset.target;
            const dur = 1400, start = performance.now();
            const tick = now => {
                const p = Math.min((now - start) / dur, 1);
                const ease = 1 - Math.pow(1 - p, 3);
                e.target.textContent = Math.floor(ease * target) + '+';
                if (p < 1) requestAnimationFrame(tick);
                else e.target.textContent = target + '+';
            };
            requestAnimationFrame(tick);
        }
    });
}, { threshold: 0.5 });
counters.forEach(c => countObs.observe(c));

// ─── Chatbot ─────────────────────────────────────────────────────────────────
const fab = document.getElementById('chatFab');
const panel = document.getElementById('chatPanel');
const messages = document.getElementById('chatMessages');
const form = document.getElementById('chatForm');
const input = document.getElementById('chatInput');
const badge = document.querySelector('.chat-badge');
const openIcon = document.querySelector('.chat-icon-open');
const closeIcon = document.querySelector('.chat-icon-close');

let isOpen = false;

fab.addEventListener('click', () => {
    isOpen = !isOpen;
    panel.classList.toggle('open', isOpen);
    openIcon.classList.toggle('hidden', isOpen);
    closeIcon.classList.toggle('hidden', !isOpen);
    if (isOpen && badge) badge.remove();
    if (isOpen) input.focus();
});

// Knowledge base responses
const knowledge = {
    skills: `I'm skilled in:\n• 🐍 Python, NumPy, Pandas, Scikit-learn\n• 🔗 LangChain, LangGraph, RAG Pipelines\n• 🤖 LLMs: GPT, Claude, Llama, Mistral, Ollama\n• 🗄️ Vector DBs: FAISS, Chroma, Pinecone, Weaviate\n• 🛠️ Docker, FastAPI, Streamlit, n8n`,
    projects: `Featured projects:\n• 🏛️ LocalGov Navigator – Offline RAG chatbot for government schemes (LangChain + FAISS + Ollama)\n• 🔬 Multi-Tool AI Research Agent – ReAct agent with Wikipedia/arXiv tools\n• 📚 Enterprise Knowledge RAG – 1000+ docs, <100ms response\n• 🧑‍💼 AI HR Assistant – Gemini + FastAPI + Streamlit`,
    experience: `Work experience:\n• 💼 AI R&D Intern @ Laneway (Nov 2025 – Feb 2026) – Led RAG pipeline, 45% efficiency gains\n• 🔭 R&D Intern @ CoCreate Ventures (Oct 2024 – Mar 2025) – 5+ AI MVPs, Samsung finalist`,
    hire: `Manish is actively looking for AI Engineering roles! You can:\n• 📧 Email: manishmaniyadhav@gmail.com\n• 💼 LinkedIn: linkedin.com/in/manish050\n• 📄 Download his resume from the Resume section above`,
    education: `🎓 B.E. Computer Science\nVivekananda College of Engineering and Technology\nAug 2021 – May 2025, Puttur, Karnataka`,
    contact: `You can reach Manish at:\n📞 +91-8139817262\n📧 manishmaniyadhav@gmail.com\n💼 linkedin.com/in/manish050\n👾 github.com/manishzzz`,
    resume: `You can view or download Manish's resume in the Resume section of this page! Just scroll up or click "Resume" in the navbar.`,
};

function getReply(msg) {
    const m = msg.toLowerCase();
    if (m.match(/skill|tech|language|framework|python|tool/)) return knowledge.skills;
    if (m.match(/project|built|made|work on/)) return knowledge.projects;
    if (m.match(/experience|intern|job|work|company/)) return knowledge.experience;
    if (m.match(/hire|recruit|job|opportun|contact|reach|email|phone/)) return knowledge.hire;
    if (m.match(/edu|college|degree|study|university/)) return knowledge.education;
    if (m.match(/resume|cv|download/)) return knowledge.resume;
    if (m.match(/contact|reach|email|phone|linkedin/)) return knowledge.contact;
    if (m.match(/hello|hi|hey|who|about|manish/)) return `👋 Hi! I'm Manish's AI assistant. Manish is an AI Engineer specializing in RAG pipelines, LLMs, and vector databases. What would you like to know?`;
    return `I'm not sure about that specific question, but I'd love to connect you with Manish directly!\n📧 manishmaniyadhav@gmail.com\n💼 linkedin.com/in/manish050`;
}

function addMsg(text, who) {
    const div = document.createElement('div');
    div.className = `chat-msg ${who}`;
    div.textContent = text;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
}

function showTyping() {
    const div = document.createElement('div');
    div.className = 'chat-msg bot typing';
    div.id = 'typingIndicator';
    div.innerHTML = '<span><i></i><i></i><i></i></span>';
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
}

function removeTyping() {
    const t = document.getElementById('typingIndicator');
    if (t) t.remove();
}

form.addEventListener('submit', e => {
    e.preventDefault();
    const val = input.value.trim();
    if (!val) return;
    addMsg(val, 'user');
    input.value = '';
    showTyping();
    setTimeout(() => {
        removeTyping();
        addMsg(getReply(val), 'bot');
    }, 900 + Math.random() * 500);
});

// Suggestion chips
document.querySelectorAll('.suggestion').forEach(btn => {
    btn.addEventListener('click', () => {
        const q = btn.textContent;
        addMsg(q, 'user');
        document.getElementById('chatSuggestions').style.display = 'none';
        showTyping();
        setTimeout(() => {
            removeTyping();
            addMsg(getReply(q), 'bot');
        }, 900 + Math.random() * 400);
    });
});

// ─── Hero parallax (light, smooth) ───────────────────────────────────────────
window.addEventListener('scroll', () => {
    const y = window.scrollY;
    const hero = document.querySelector('.hero-content');
    if (!hero || y > window.innerHeight) return;
    const factor = y / window.innerHeight;
    hero.style.transform = `translateY(${y * 0.18}px)`;
    hero.style.opacity = 1 - factor * 0.9;
}, { passive: true });
